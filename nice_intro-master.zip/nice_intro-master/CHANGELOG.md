## [0.1.0] - [2020-04-26]

* Initial build for Flutter nice button library

## [0.1.1] - [2020-04-26]

* Minor update: update package description


## [0.1.2] - [2020-04-27]

* Minor update: update the doc and the example


## [0.1.3] - [2020-05-04]

* Minor update: updates the doc and the example
* Add `physic` parameter to the `IntroScreens` class

## [0.1.4] - [2020-05-011]

* Minor update: updates the doc and the example
* Add `header` parameter to the `IntroScreen` class to set a custom widget for the header of a slide
